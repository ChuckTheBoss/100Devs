//Create a button that adds 1 to a botScore stored in localStorage 


