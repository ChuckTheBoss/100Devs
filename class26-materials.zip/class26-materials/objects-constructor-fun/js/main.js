//Create a constructor with 4 properties and 3 methods
